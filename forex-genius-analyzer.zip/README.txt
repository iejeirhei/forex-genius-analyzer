Forex Genius Analyzer App

Instructions:
1. Open with Expo
2. Run `npm install`
3. Build APK using `eas build -p android`

Password: Alphasuccesscreed$